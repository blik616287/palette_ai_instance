{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "hue.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "hue.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "hue.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common annotations
*/}}
{{- define "hue.annotations" -}}
meta.helm.sh/release-name: {{ .Release.Name | quote }}
meta.helm.sh/release-namespace: {{ .Release.Namespace | quote }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "hue.labels" -}}
helm.sh/chart: {{ include "hue.chart" . }}
{{ include "hue.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "hue.selectorLabels" -}}
app.kubernetes.io/name: {{ include "hue.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "hue.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "hue.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Get audit logging configuration - checks global first, then falls back to local values
*/}}
{{- define "hue.auditLogging" -}}
{{- if and .Values.global .Values.global.auditLogging -}}
{{- .Values.global.auditLogging | toYaml -}}
{{- else if .Values.auditLogging -}}
{{- .Values.auditLogging | toYaml -}}
{{- else -}}
{{- dict "enabled" false "alertmanagerURL" "" "timeout" "" "basicAuth" (dict "username" "" "password" "") "tls" (dict "insecureSkipVerify" false "caCertSecretName" "" "minVersion" "" "maxVersion" "") "httpProxy" "" "httpsProxy" "" "noProxy" "" | toYaml -}}
{{- end -}}
{{- end -}}

{{/*
Get versioning type - checks global first, then falls back to mural values
*/}}
{{- define "hue.versioningType" -}}
{{- $versioningType := "" -}}
{{- if and .Values.mural .Values.mural.featureFlags .Values.mural.featureFlags.versioningType -}}
  {{- $versioningType = .Values.mural.featureFlags.versioningType -}}
{{- end -}}
{{- if .Values.global -}}
  {{- if .Values.global.featureFlags -}}
    {{- $versioningType = .Values.global.featureFlags.versioningType | default $versioningType -}}
  {{- end -}}
{{- end -}}
{{- $versioningType -}}
{{- end -}}
