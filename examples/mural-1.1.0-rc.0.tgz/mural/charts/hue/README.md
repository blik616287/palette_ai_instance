# hue helm chart

## TL;DR

```bash
helm install hue oci://public.ecr.aws/mural/hue -n mural-system --create-namespace
```

## Prerequisites

- Kubernetes >= v1.19
  
## Parameters

### hue parameters

| Name                                   | Description                                                                                                                                                                                                                                                                              | Value                                                         |
| -------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| `federationProvider`                   | The multi-cluster federation provider to use. Supported values: [ OCM ].                                                                                                                                                                                                                 | `OCM`                                                         |
| `definitionRevisionLimit`              | Definition revision limit                                                                                                                                                                                                                                                                | `2`                                                           |
| `concurrentReconciles`                 | The maximum concurrent reconciles for the hue controller                                                                                                                                                                                                                                 | `4`                                                           |
| `webhookWaitTimeout`                   | The timeout for a TCP connection when waiting for the webhook to come up.                                                                                                                                                                                                                | `5s`                                                          |
| `garbageCollectorServiceAccount`       | The service account used by Kubernetes garbage collector for owner reference deletions                                                                                                                                                                                                   | `system:serviceaccount:kube-system:generic-garbage-collector` |
| `definitionUpsert.ociRegistryInterval` | The interval at which each spoke cluster will upsert mural-definitions Flux artifacts to account for OCI registry configuration changes                                                                                                                                                  | `5m`                                                          |
| `definitionUpsert.syncInterval`        | The interval at which each spoke cluster will sync mural-definitions from the OCI registry                                                                                                                                                                                               | `1m`                                                          |
| `controllerArgs.reSyncPeriod`          | The period for resyncing workloads, workloaddeployments, and workloadpolicies                                                                                                                                                                                                            | `5m`                                                          |
| `controllerArgs.verbosity`             | Log verbosity level. Supported values: [0,10]. 0 is the default and 10 is the most verbose.                                                                                                                                                                                              | `0`                                                           |
| `clusterType`                          | The type of cluster: [ hub | spoke | hub-as-spoke ]                                                                                                                                                                                                                                      | `hub-as-spoke`                                                |
| `projectName`                          | The name of the project that the managed cluster belongs to. If a Spoke belongs to a Project, the Project resource, as well as any supporting resources (Tenant, Settings, integration secrets) will be automatically federated to the Spoke. Only applicable when ClusterType == spoke. | `""`                                                          |

### OCI registry parameters. If specified, OCI deployment flow will be enabled.

| Name                              | Description                                                                                                                                                                                                            | Value                                           |
| --------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------- |
| `ociRegistry.enabled`             | whether to enable an OCI registry for tracking Workload revisions                                                                                                                                                      | `true`                                          |
| `ociRegistry.endpoint`            | OCI registry endpoint                                                                                                                                                                                                  | `oci://zot.mural-system.svc.cluster.local:5000` |
| `ociRegistry.repository`          | OCI registry repository to store Workload revisions in                                                                                                                                                                 | `mural-workloads`                               |
| `ociRegistry.basicAuth.username`  | OCI registry username. Ignored if provider is not set to 'generic'. Mutually exclusive with basicAuthSecretName.                                                                                                       | `user`                                          |
| `ociRegistry.basicAuth.password`  | OCI registry password. Ignored if provider is not set to 'generic'. Mutually exclusive with basicAuthSecretName.                                                                                                       | `user`                                          |
| `ociRegistry.basicAuthSecretName` | The secret to use for OCI registry basic auth. Mutually exclusive with basicAuth. Must exist in the release namespace.                                                                                                 | `""`                                            |
| `ociRegistry.insecure`            | Insecure allows connecting to a non-TLS HTTP container registry.                                                                                                                                                       | `true`                                          |
| `ociRegistry.interval`            | Interval at which the OCIRepository URL is checked for updates. This interval is approximate and may be subject to jitter to ensure efficient use of resources.                                                        | `5m`                                            |
| `ociRegistry.timeout`             | The timeout for remote OCI Repository operations like pulling & pushing, defaults to 60s.                                                                                                                              | `60s`                                           |
| `ociRegistry.provider`            | The credential provider to use for OCI registry. Supported values: 'aws', 'azure', 'gcp', 'generic'.                                                                                                                   | `generic`                                       |
| `ociRegistry.certData`            | The CA certificate, TLS certificate, and TLS private key to use for the OCI registry. Mutually exclusive with certSecretName.                                                                                          | `{}`                                            |
| `ociRegistry.certSecretName`      | If insecure is false, the secret to use for the OCI registry certificate. Mutually exclusive with certData. Must contain 'tls.crt' and 'tls.key' or 'ca.crt' keys (or all three). Must exist in the release namespace. | `""`                                            |
| `ociRegistry.proxyData`           | The proxy configuration to use for the OCI registry. Mutually exclusive with proxySecretName.                                                                                                                          | `{}`                                            |
| `ociRegistry.proxySecretName`     | The secret to use for proxy configuration. Must contain an 'address' key. Optionally may include 'username' and 'password' keys. Mutually exclusive with proxyData. Must exist in the release namespace.               | `""`                                            |
| `tokenCache.enabled`              | Whether to enable the OCI provider token cache.                                                                                                                                                                        | `true`                                          |
| `tokenCache.maxSize`              | The maximum size of the token cache in number of tokens.                                                                                                                                                               | `100`                                           |
| `tokenCache.maxDuration`          | The maximum duration a token is cached.                                                                                                                                                                                | `1h`                                            |

### Kustomization parameters

| Name                          | Description                                                                                                                                        | Value   |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| `kustomization.interval`      | The interval at which to reconcile Kustomizations. This interval is approximate and may be subject to jitter to ensure efficient use of resources. | `5m`    |
| `kustomization.timeout`       | Timeout for validation, apply and health checking operations. Defaults to 'Interval' duration.                                                     | `1m`    |
| `kustomization.retryInterval` | Retry interval for the Flux Kustomization. This interval is approximate and may be subject to jitter to ensure efficient use of resources.         | `1m`    |
| `kustomization.force`         | Force instructs the kustomize controller to recreate resources when patching fails due to an immutable field change.                               | `false` |

### Hue controller parameters

| Name                        | Description                                | Value                      |
| --------------------------- | ------------------------------------------ | -------------------------- |
| `annotations`               | Annotations to add to the hue controller   | `{}`                       |
| `labels`                    | Labels to add to the hue controller        | `{}`                       |
| `replicaCount`              | The hue controller replica count           | `1`                        |
| `imageRegistry`             | Image registry                             | `""`                       |
| `image.repository`          | Image repository                           | `public.ecr.aws/mural/hue` |
| `image.tag`                 | x-release-please-version                   | `v0.12.1`                  |
| `image.pullPolicy`          | Image pull policy                          | `IfNotPresent`             |
| `resources.requests.cpu`    | hue controller deployment's cpu request    | `250m`                     |
| `resources.requests.memory` | hue controller deployment's memory request | `128Mi`                    |
| `healthCheck.port`          | hue controller manager's health check port | `9440`                     |

### Common parameters

| Name                                                 | Description                                                                                                            | Value                    |
| ---------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `imagePullSecrets`                                   | Image pull secrets                                                                                                     | `[]`                     |
| `nameOverride`                                       | Override name                                                                                                          | `""`                     |
| `fullnameOverride`                                   | Fullname override                                                                                                      | `hue`                    |
| `serviceAccount.create`                              | Specifies whether a service account should be created                                                                  | `true`                   |
| `serviceAccount.name`                                | The name of the service account to use. If not set and create is true, a name is generated using the fullname template | `nil`                    |
| `serviceAccount.annotations`                         | Annotations to add to the service account                                                                              | `{}`                     |
| `serviceAccount.labels`                              | Labels to add to the service account                                                                                   | `{}`                     |
| `podSecurityContext.seccompProfile.type`             | Seccomp profile type to use for the hue pod                                                                            | `RuntimeDefault`         |
| `securityContext.allowPrivilegeEscalation`           | Allow privilege escalation                                                                                             | `false`                  |
| `securityContext.capabilities.drop`                  | List of capabilities to drop                                                                                           | `["ALL"]`                |
| `securityContext.readOnlyRootFilesystem`             | Enable read only root filesystem for the container                                                                     | `true`                   |
| `securityContext.runAsNonRoot`                       | Run container as non-root                                                                                              | `true`                   |
| `nodeSelector`                                       | Node selector                                                                                                          | `{}`                     |
| `tolerations`                                        | Tolerations                                                                                                            | `[]`                     |
| `affinity`                                           | Affinity                                                                                                               | `{}`                     |
| `rbac.create`                                        | Specifies whether a RBAC role should be created                                                                        | `true`                   |
| `admissionWebhooks.enabled`                          | Whether to enable admission webhooks                                                                                   | `true`                   |
| `admissionWebhooks.failurePolicy`                    | The failure policy for admission webhooks                                                                              | `Fail`                   |
| `admissionWebhooks.certificate.mountPath`            | The mount path for the certificate                                                                                     | `/etc/k8s-webhook-certs` |
| `admissionWebhooks.certManager.revisionHistoryLimit` | The revision history limit for the cert-manager                                                                        | `3`                      |
| `admissionWebhooks.resources.requests.cpu`           | hue webhook deployment's cpu request                                                                                   | `250m`                   |
| `admissionWebhooks.resources.requests.memory`        | hue webhook deployment's memory request                                                                                | `128Mi`                  |
| `admissionWebhooks.webhookService.type`              | hue webhook service type                                                                                               | `ClusterIP`              |
| `admissionWebhooks.webhookService.port`              | hue webhook service port                                                                                               | `9443`                   |
| `kubeClient.qps`                                     | The qps for reconcile clients                                                                                          | `400`                    |
| `kubeClient.burst`                                   | The burst for reconcile clients                                                                                        | `600`                    |

### Audit Logging parameters

| Name                                               | Description                                                                                                                                   | Value                                                     |
| -------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| `auditLogging.enabled`                             | Whether to enable sending audit logs to Alertmanager                                                                                          | `false`                                                   |
| `auditLogging.alertmanagerURL`                     | The URL of the Alertmanager instance to send audit logs to                                                                                    | `http://alertmanager.mural-system.svc.cluster.local:9093` |
| `auditLogging.timeout`                             | The timeout for Alertmanager requests (default: 2s)                                                                                           | `2s`                                                      |
| `auditLogging.basicAuth.username`                  | Basic auth username for Alertmanager                                                                                                          | `""`                                                      |
| `auditLogging.basicAuth.password`                  | Basic auth password for Alertmanager                                                                                                          | `""`                                                      |
| `auditLogging.tls.insecureSkipVerify`              | Skip TLS certificate verification                                                                                                             | `false`                                                   |
| `auditLogging.tls.caCertSecretName`                | The secret containing the CA certificate for Alertmanager TLS verification. Must contain a 'ca.crt' key. Must exist in the release namespace. | `""`                                                      |
| `auditLogging.tls.minVersion`                      | Minimum TLS version for Alertmanager (TLS12, TLS13)                                                                                           | `""`                                                      |
| `auditLogging.tls.maxVersion`                      | Maximum TLS version for Alertmanager (TLS12, TLS13)                                                                                           | `""`                                                      |
| `auditLogging.httpProxy`                           | HTTP proxy URL for Alertmanager requests (sets HTTP_PROXY env var). Supports basic auth: http://user:pass@proxy:8080                          | `""`                                                      |
| `auditLogging.httpsProxy`                          | HTTPS proxy URL for Alertmanager requests (sets HTTPS_PROXY env var). Supports basic auth: https://user:pass@proxy:8080                       | `""`                                                      |
| `auditLogging.noProxy`                             | Comma-separated list of hosts to exclude from proxying (sets NO_PROXY env var). Example: 127.0.0.1,localhost                                  | `""`                                                      |
| `defaultDefinitions.enabled`                       | Whether to create/update Mural's default definitions                                                                                          | `true`                                                    |
| `defaultDefinitions.image.repository`              | The repository for the definitions installer image                                                                                            | `public.ecr.aws/mural/hue-definitions`                    |
| `defaultDefinitions.image.tag`                     | The tag for the definitions installer image (defaults to chart appVersion)                                                                    | `v0.12.1`                                                 |
| `defaultDefinitions.image.pullPolicy`              | The pull policy for the definitions installer image                                                                                           | `IfNotPresent`                                            |
| `defaultDefinitions.image.pullSecrets`             | Image pull secrets for the definitions installer image                                                                                        | `[]`                                                      |
| `defaultDefinitions.job.backoffLimit`              | Number of retries before considering the Job as failed                                                                                        | `3`                                                       |
| `defaultDefinitions.job.ttlSecondsAfterFinished`   | TTL for the Job after it finishes                                                                                                             | `300`                                                     |
| `defaultDefinitions.job.nodeSelector`              | Node selector for the definitions installer Job                                                                                               | `{}`                                                      |
| `defaultDefinitions.job.tolerations`               | Tolerations for the definitions installer Job                                                                                                 | `[]`                                                      |
| `defaultDefinitions.job.affinity`                  | Affinity rules for the definitions installer Job                                                                                              | `{}`                                                      |
| `defaultDefinitions.job.resources.requests.memory` | Memory request for the definitions installer Job                                                                                              | `128Mi`                                                   |
| `defaultDefinitions.job.resources.requests.cpu`    | CPU request for the definitions installer Job                                                                                                 | `100m`                                                    |
| `defaultDefinitions.job.resources.limits.memory`   | Memory limit for the definitions installer Job                                                                                                | `256Mi`                                                   |
| `defaultDefinitions.job.resources.limits.cpu`      | CPU limit for the definitions installer Job                                                                                                   | `200m`                                                    |
| `defaultDefinitions.job.extraEnv`                  | Additional environment variables for the definitions installer Job                                                                            | `[]`                                                      |
| `devspaceEnabled`                                  | Used for dev.                                                                                                                                 | `false`                                                   |
