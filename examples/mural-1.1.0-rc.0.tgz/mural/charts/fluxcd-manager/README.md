# fluxcd-manager helm chart

## TL;DR

```bash
helm install fluxcd-manager oci://public.ecr.aws/mural/third-party/fluxcd-manager -n mural-system --create-namespace
```

## Prerequisites

- Kubernetes >= v1.19
  
## Parameters

### Global parameters

| Name               | Description                                      | Value |
| ------------------ | ------------------------------------------------ | ----- |
| `nameOverride`     | The name override to use for the deployment      | `""`  |
| `fullnameOverride` | The full name override to use for the deployment | `""`  |

### FluxCD Addon Controller parameters

| Name                                       | Description                                                                                              | Value                                  |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------- | -------------------------------------- |
| `image`                                    | The repository to use for the FluxCD addon controller image                                              | `ghcr.io/kluster-manager/fluxcd-addon` |
| `tag`                                      | The tag to use for the FluxCD addon controller image. If not set, the appVersion from Chart.yaml is used | `nil`                                  |
| `imagePullPolicy`                          | The image pull policy to use for the FluxCD addon controller image                                       | `IfNotPresent`                         |
| `securityContext.allowPrivilegeEscalation` | Allow privilege escalation for the container                                                             | `false`                                |
| `securityContext.capabilities.drop`        | List of capabilities to drop from the container                                                          | `["ALL"]`                              |
| `securityContext.privileged`               | Run container in privileged mode                                                                         | `false`                                |
| `securityContext.runAsNonRoot`             | Require container to run as non-root user                                                                | `true`                                 |
| `securityContext.readOnlyRootFilesystem`   | Enable read-only root filesystem for the container                                                       | `true`                                 |
| `securityContext.seccompProfile.type`      | Seccomp profile type to use                                                                              | `RuntimeDefault`                       |
| `resources`                                | Resource requests and limits for the FluxCD addon controller container                                   | `{}`                                   |

### Addon Configuration

| Name                    | Description                                                                                               | Value                            |
| ----------------------- | --------------------------------------------------------------------------------------------------------- | -------------------------------- |
| `kubeconfigSecretName`  | The name of the secret containing the kubeconfig for the hub cluster. If empty, in-cluster config is used | `""`                             |
| `addonManagerNamespace` | The namespace where the FluxCD addon manager will be deployed on managed clusters                         | `open-cluster-management-fluxcd` |
| `installStrategy.type`  | The type of install strategy to use (Placements or Manual)                                                | `Placements`                     |

### Placement parameters

| Name               | Description                                    | Value    |
| ------------------ | ---------------------------------------------- | -------- |
| `placement.create` | Whether to create a default Placement resource | `true`   |
| `placement.name`   | The name of the default Placement resource     | `global` |

### Kubectl Helper parameters

| Name            | Description                                           | Value                                   |
| --------------- | ----------------------------------------------------- | --------------------------------------- |
| `kubectl.image` | The kubectl helper image to use for FluxCD operations | `ghcr.io/appscode/kubectl-nonroot:1.31` |
