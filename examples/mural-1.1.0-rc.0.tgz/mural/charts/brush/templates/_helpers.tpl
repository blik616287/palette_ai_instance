{{/*
Expand the name of the chart.
*/}}
{{- define "brush.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "brush.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "brush.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "brush.annotations" -}}
meta.helm.sh/release-name: {{ .Release.Name | quote }}
meta.helm.sh/release-namespace: {{ .Release.Namespace | quote }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "brush.labels" -}}
helm.sh/chart: {{ include "brush.chart" . }}
{{ include "brush.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "brush.selectorLabels" -}}
app.kubernetes.io/name: {{ include "brush.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "brush.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "brush.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Create the name of the mural chart repo
*/}}
{{- define "brush.muralChartRepo" -}}
{{- .Values.mural.source.repository | default "oci://public.ecr.aws/mural/mural" }}
{{- end }}

{{/*
Create a mural chart repo basic auth secret name
*/}}
{{- define "brush.basicAuthSecretName" -}}
{{- if .Values.mural.source.basicAuthSecretName }}
{{- .Values.mural.source.basicAuthSecretName }}
{{- else }}
{{- printf "mural-source-basic-auth-secret" }}
{{- end }}
{{- end -}}

{{/*
Create a mural chart repo TLS certificate secret name
*/}}
{{- define "brush.certSecretName" -}}
{{- if .Values.mural.source.certSecretName }}
{{- .Values.mural.source.certSecretName }}
{{- else }}
{{- printf "mural-source-tls-secret" }}
{{- end }}
{{- end -}}

{{/*
Create a mural chart repo proxy secret name
*/}}
{{- define "brush.proxySecretName" -}}
{{- if .Values.mural.source.proxySecretName }}
{{- .Values.mural.source.proxySecretName }}
{{- else }}
{{- printf "mural-source-proxy-secret" }}
{{- end }}
{{- end -}}

{{/* 
Define the source type
*/}}
{{- define "brush.sourceType" -}}
{{- first (splitList  ":" .Values.mural.source.repository) -}}
{{- end -}}

{{/*
Create a mural chart release tag
*/}}
{{- define "brush.releaseTag" -}}
{{- if and .Values.global .Values.global.muralVersion -}}
{{- .Values.global.muralVersion -}}
{{- else if .Values.mural.releaseVersion -}}
{{- .Values.mural.releaseVersion -}}
{{- else -}}
{{- printf "" -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the cert-manager chart repo
*/}}
{{- define "brush.certManagerChartRepo" -}}
{{- .Values.certManager.source.repository }}
{{- end }}

{{/*
Create a cert-manager chart repo basic auth secret name
*/}}
{{- define "brush.certManagerBasicAuthSecretName" -}}
{{- if .Values.certManager.source.basicAuthSecretName }}
{{- .Values.certManager.source.basicAuthSecretName }}
{{- else }}
{{- printf "cert-manager-source-basic-auth-secret" }}
{{- end }}
{{- end -}}

{{/*
Create a cert-manager chart repo TLS certificate secret name
*/}}
{{- define "brush.certManagerCertSecretName" -}}
{{- if .Values.certManager.source.certSecretName }}
{{- .Values.certManager.source.certSecretName }}
{{- else }}
{{- printf "cert-manager-source-tls-secret" }}
{{- end }}
{{- end -}}

{{/*
Create a cert-manager chart repo proxy secret name
*/}}
{{- define "brush.certManagerProxySecretName" -}}
{{- if .Values.certManager.source.proxySecretName }}
{{- .Values.certManager.source.proxySecretName }}
{{- else }}
{{- printf "cert-manager-source-proxy-secret" }}
{{- end }}
{{- end -}}

{{/*
Define the cert-manager source type
*/}}
{{- define "brush.certManagerSourceType" -}}
{{- first (splitList  ":" .Values.certManager.source.repository) -}}
{{- end -}}

{{/*
Create a cert-manager chart release tag
*/}}
{{- define "brush.certManagerReleaseTag" -}}
{{- if and .Values.global .Values.global.certManagerVersion -}}
{{- .Values.global.certManagerVersion -}}
{{- else if .Values.certManager.releaseVersion -}}
{{- .Values.certManager.releaseVersion -}}
{{- else -}}
{{- printf "" -}}
{{- end -}}
{{- end -}}

{{/*
Create a mural-crds chart release tag
*/}}
{{- define "brush.muralCrdsReleaseTag" -}}
{{- if and .Values.global .Values.global.muralCrdsVersion -}}
{{- .Values.global.muralCrdsVersion -}}
{{- else if and .Values.muralCrds .Values.muralCrds.releaseVersion -}}
{{- .Values.muralCrds.releaseVersion -}}
{{- else -}}
{{- printf "" -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the mural-crds chart repo (same as mural)
*/}}
{{- define "brush.muralCrdsChartRepo" -}}
{{- .Values.mural.source.repository | default "oci://public.ecr.aws/mural" | trimSuffix "/mural" | printf "%s/mural-crds" }}
{{- end }}
