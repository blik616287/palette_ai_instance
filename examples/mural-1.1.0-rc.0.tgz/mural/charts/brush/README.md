# brush helm chart

## TL;DR

```bash
helm install brush oci://public.ecr.aws/mural/brush -n app-system --create-namespace
```

## Prerequisites

- Kubernetes >= v1.19
  
## Parameters

### brush controller parameters

| Name                                            | Description                                                                                                             | Value                        |
| ----------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | ---------------------------- |
| `replicaCount`                                  | The number of replicas to use for the deployment                                                                        | `1`                          |
| `image.repository`                              | The repository to use for the image                                                                                     | `public.ecr.aws/mural/brush` |
| `image.tag`                                     | x-release-please-version                                                                                                | `v0.5.13`                    |
| `image.pullPolicy`                              | The pull policy to use for the image                                                                                    | `IfNotPresent`               |
| `imagePullSecrets`                              | The pull secrets to use for the image                                                                                   | `[]`                         |
| `nameOverride`                                  | The name override to use for the deployment                                                                             | `""`                         |
| `fullnameOverride`                              | The full name override to use for the deployment                                                                        | `brush`                      |
| `serviceAccount.create`                         | Whether to create a service account                                                                                     | `true`                       |
| `serviceAccount.automount`                      | Whether to automatically mount the service account's API credentials                                                    | `true`                       |
| `serviceAccount.annotations`                    | Annotations to add to the service account                                                                               | `{}`                         |
| `serviceAccount.name`                           | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. | `""`                         |
| `podAnnotations`                                | Annotations to add to the pod                                                                                           | `{}`                         |
| `podLabels`                                     | Labels to add to the pod                                                                                                | `{}`                         |
| `podSecurityContext.seccompProfile.type`        | Seccomp profile type to use for the brush manager pod                                                                   | `RuntimeDefault`             |
| `securityContext.allowPrivilegeEscalation`      | Allow privilege escalation                                                                                              | `false`                      |
| `securityContext.capabilities.drop`             | List of capabilities to drop                                                                                            | `["ALL"]`                    |
| `securityContext.readOnlyRootFilesystem`        | Enable read only root filesystem for the container                                                                      | `true`                       |
| `securityContext.runAsNonRoot`                  | Run container as non-root                                                                                               | `true`                       |
| `service.type`                                  | The type of service to create                                                                                           | `ClusterIP`                  |
| `service.port`                                  | The port to use for the service                                                                                         | `80`                         |
| `ingress.enabled`                               | Whether to create an ingress resource                                                                                   | `false`                      |
| `ingress.className`                             | The class name for the ingress resource                                                                                 | `""`                         |
| `ingress.annotations`                           | Annotations to add to the ingress resource                                                                              | `{}`                         |
| `ingress.hosts[0].host`                         | The host to add to the ingress resource                                                                                 | `chart-example.local`        |
| `ingress.hosts[0].paths[0].path`                | The path to add to the ingress resource                                                                                 | `/`                          |
| `ingress.hosts[0].paths[0].pathType`            | The path type for the ingress resource                                                                                  | `ImplementationSpecific`     |
| `ingress.tls`                                   | The TLS configuration for the ingress resource                                                                          | `[]`                         |
| `resources`                                     | The resources to add to the deployment                                                                                  | `{}`                         |
| `healthCheck.port`                              | The port to use for the health check                                                                                    | `9440`                       |
| `autoscaling.enabled`                           | Whether to enable autoscaling                                                                                           | `false`                      |
| `autoscaling.minReplicas`                       | The minimum number of replicas to use for the deployment                                                                | `1`                          |
| `autoscaling.maxReplicas`                       | The maximum number of replicas to use for the deployment                                                                | `100`                        |
| `autoscaling.targetCPUUtilizationPercentage`    | The target CPU utilization percentage for the deployment                                                                | `80`                         |
| `autoscaling.targetMemoryUtilizationPercentage` | The target memory utilization percentage for the deployment                                                             | `80`                         |
| `volumes`                                       | Additional volumes on the output Deployment definition.                                                                 | `[]`                         |
| `volumeMounts`                                  | Additional volumeMounts on the output Deployment definition.                                                            | `[]`                         |
| `nodeSelector`                                  | The node selector to use for the deployment                                                                             | `{}`                         |
| `tolerations`                                   | The tolerations to use for the deployment                                                                               | `[]`                         |
| `affinity`                                      | The affinity to use for the deployment                                                                                  | `{}`                         |
| `devspaceEnabled`                               | Whether to enable devspace                                                                                              | `false`                      |
| `admissionWebhooks.enabled`                     | Whether to enable admission webhooks                                                                                    | `false`                      |
| `admissionWebhooks.revisionHistoryLimit`        | The revision history limit for the admission webhooks                                                                   | `10`                         |
| `admissionWebhooks.certificate.mountPath`       | The mount path for the certificate                                                                                      | `/etc/k8s-webhook-certs`     |

### mural parameters

| Name                               | Description                                                                                                                                                                                                            | Value                              |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `mural.source.repository`          | The repository to use for the Mural Helm chart.                                                                                                                                                                        | `oci://public.ecr.aws/mural/mural` |
| `mural.source.basicAuth`           | The basic auth credentials to use for the Mural Helm chart. Mutually exclusive with basicAuthSecretName.                                                                                                               | `{}`                               |
| `mural.source.basicAuthSecretName` | The secret to use for Helm repository basic auth. Mutually exclusive with basicAuth. Must exist in the release namespace.                                                                                              | `""`                               |
| `mural.source.insecure`            | Insecure allows connecting to a non-TLS HTTP Helm repository.                                                                                                                                                          | `false`                            |
| `mural.source.interval`            | Interval at which the Helm repository URL is checked for updates. This interval is approximate and may be subject to jitter to ensure efficient use of resources.                                                      | `300s`                             |
| `mural.source.timeout`             | The timeout for pulling from the Helm repository, defaults to 60s.                                                                                                                                                     | `60s`                              |
| `mural.source.provider`            | The credential provider to use for OCI-based Helm repository. Supported values: 'aws', 'azure', 'gcp', 'generic'.                                                                                                      | `generic`                          |
| `mural.source.certData`            | The CA certificate, TLS certificate, and TLS private key to use for the OCI registry. Mutually exclusive with certSecretName.                                                                                          | `{}`                               |
| `mural.source.certSecretName`      | If insecure is false, the secret to use for the OCI registry certificate. Mutually exclusive with certData. Must contain 'tls.crt' and 'tls.key' or 'ca.crt' keys (or all three). Must exist in the release namespace. | `""`                               |
| `mural.source.proxyData`           | The proxy configuration to use for OCI-based Helm repository. Mutually exclusive with proxySecretName.                                                                                                                 | `{}`                               |
| `mural.source.proxySecretName`     | The secret to use for proxy configuration. Must contain an 'address' key. Optionally may include 'username' and 'password' keys. Mutually exclusive with proxyData. Must exist in the release namespace.               | `""`                               |
| `mural.release.interval`           | The interval at which the Mural Helm chart is reconciled on each spoke cluster.                                                                                                                                        | `5m`                               |
| `mural.release.timeout`            | The timeout for installing the Mural Helm chart on each spoke cluster.                                                                                                                                                 | `20m`                              |
| `mural.release.crdPolicy`          | The CRD policy for the Mural Helm release. Valid values: Create, CreateReplace, Skip.                                                                                                                                  | `CreateReplace`                    |
| `mural.release.maxHistory`         | The maximum number of revisions to keep in Mural Helm release history. 0 = unlimited.                                                                                                                                  | `0`                                |

### mural-crds parameters

| Name                           | Description                                                                                | Value           |
| ------------------------------ | ------------------------------------------------------------------------------------------ | --------------- |
| `muralCrds.release.crdPolicy`  | The CRD policy for the mural-crds Helm release. Valid values: Create, CreateReplace, Skip. | `CreateReplace` |
| `muralCrds.release.maxHistory` | The maximum number of revisions to keep in mural-crds Helm release history. 0 = unlimited. | `1`             |

### cert-manager parameters

| Name                                     | Description                                                                                                                                                                                                            | Value                        |
| ---------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------- |
| `certManager.enabled`                    | Whether to enable cert-manager installation                                                                                                                                                                            | `true`                       |
| `certManager.source.repository`          | The repository to use for the cert-manager Helm chart.                                                                                                                                                                 | `https://charts.jetstack.io` |
| `certManager.source.basicAuth`           | The basic auth credentials to use for the cert-manager Helm chart. Mutually exclusive with basicAuthSecretName.                                                                                                        | `{}`                         |
| `certManager.source.basicAuthSecretName` | The secret to use for Helm repository basic auth. Mutually exclusive with basicAuth. Must exist in the release namespace.                                                                                              | `""`                         |
| `certManager.source.insecure`            | Insecure allows connecting to a non-TLS HTTP Helm repository.                                                                                                                                                          | `false`                      |
| `certManager.source.interval`            | Interval at which the Helm repository URL is checked for updates. This interval is approximate and may be subject to jitter to ensure efficient use of resources.                                                      | `300s`                       |
| `certManager.source.timeout`             | The timeout for pulling from the Helm repository, defaults to 60s.                                                                                                                                                     | `60s`                        |
| `certManager.source.provider`            | The credential provider to use for OCI-based Helm repository. Supported values: 'aws', 'azure', 'gcp', 'generic'.                                                                                                      | `generic`                    |
| `certManager.source.certData`            | The CA certificate, TLS certificate, and TLS private key to use for the OCI registry. Mutually exclusive with certSecretName.                                                                                          | `{}`                         |
| `certManager.source.certSecretName`      | If insecure is false, the secret to use for the OCI registry certificate. Mutually exclusive with certData. Must contain 'tls.crt' and 'tls.key' or 'ca.crt' keys (or all three). Must exist in the release namespace. | `""`                         |
| `certManager.source.proxyData`           | The proxy configuration to use for OCI-based Helm repository. Mutually exclusive with proxySecretName.                                                                                                                 | `{}`                         |
| `certManager.source.proxySecretName`     | The secret to use for proxy configuration. Must contain an 'address' key. Optionally may include 'username' and 'password' keys. Mutually exclusive with proxyData. Must exist in the release namespace.               | `""`                         |
| `certManager.release.interval`           | The interval at which the cert-manager Helm chart is reconciled on each spoke cluster.                                                                                                                                 | `5m`                         |
| `certManager.release.timeout`            | The timeout for installing the cert-manager Helm chart on each spoke cluster.                                                                                                                                          | `20m`                        |
| `certManager.release.name`               | The name of the cert-manager Helm release.                                                                                                                                                                             | `cert-manager`               |
| `certManager.release.namespace`          | The namespace to install cert-manager into.                                                                                                                                                                            | `cert-manager`               |
| `certManager.release.crdPolicy`          | The CRD policy for the cert-manager Helm release. Valid values: Create, CreateReplace, Skip.                                                                                                                           | `Skip`                       |
| `certManager.release.maxHistory`         | The maximum number of revisions to keep in cert-manager Helm release history. 0 = unlimited.                                                                                                                           | `0`                          |
| `certManager.values`                     | Helm values to pass to cert-manager. If provided, a ConfigMap named cert-manager-spoke-values will be created and used by brush to configure cert-manager on each spoke cluster.                                       | `undefined`                  |
