{{/*
Create a .dockerconfigjson formatted registry secret value
*/}}
{{- define "dockerConfigJSON" -}}
{{- $obj := . -}}
{{- $endpoint := trimPrefix "oci://" $obj.endpoint -}}
{{- printf "{\"auths\": {\"%s\": {\"username\": \"%s\", \"password\": \"%s\", \"auth\": \"%s\"}}}" $endpoint $obj.basicAuth.username $obj.basicAuth.password (printf "%s:%s" $obj.basicAuth.username $obj.basicAuth.password | b64enc) | b64enc }}
{{- end -}}

{{/*
Determine the kubernetes provider
*/}}
{{- define "global.kubernetesProvider" -}}
{{- if and .Values.global .Values.global.kubernetesProvider -}}
{{- .Values.global.kubernetesProvider | lower -}}
{{- end -}}
{{- end -}}


{{/*
Get Global Auth sessionSecret
*/}}
{{- define "sessionSecret" -}}
{{- if and .Values.ui .Values.ui.oidc .Values.ui.oidc.sessionSecret (not (empty .Values.ui.oidc.sessionSecret)) -}}
{{- .Values.ui.oidc.sessionSecret -}}
{{- else if and .Values.oidc .Values.oidc.sessionSecret (not (empty .Values.oidc.sessionSecret)) -}}
{{- .Values.oidc.sessionSecret -}}
{{- else if and .Values.global .Values.global.auth .Values.global.auth.sessionSecret (not (empty .Values.global.auth.sessionSecret)) -}}
{{- .Values.global.auth.sessionSecret -}}
{{- else -}}
{{- "repl@c3me!!" -}}
{{- end -}}
{{- end }}

{{/*
Determine if OCI values have basic authentication credentials
*/}}
{{- define "hasBasicAuth" -}}
{{- $obj := . -}}
{{- if and $obj.basicAuth $obj.basicAuth.username $obj.basicAuth.password -}}
{{- true -}}
{{- else -}}
{{- false -}}
{{- end -}}
{{- end -}}

{{/*
Determine if OCI values have certificate data
*/}}
{{- define "hasCertData" -}}
{{- $obj := . -}}
{{- if and (kindIs "map" $obj.certData) (or (get $obj.certData "ca.crt") (and (get $obj.certData "tls.crt") (get $obj.certData "tls.key"))) -}}
{{- true -}}
{{- else -}}
{{- false -}}
{{- end -}}
{{- end -}}

{{/*
Determine if OCI values have proxy data
*/}}
{{- define "hasProxyData" -}}
{{- $obj := . -}}
{{- if and $obj.proxyData $obj.proxyData.address -}}
{{- true -}}
{{- else -}}
{{- false -}}
{{- end -}}
{{- end -}}

{{/*
Recursively clean any dict/map by removing empty values, empty strings, and empty nested objects.
Works with arbitrary depth and handles maps, slices, and scalar values.
*/}}
{{- define "deepClean" -}}
{{- if and . (kindIs "map" .) -}}
  {{- $clean := dict -}}
  {{- range $key, $value := . -}}
    {{- if kindIs "map" $value -}}
      {{- $cleaned := include "deepClean" $value | fromYaml -}}
      {{- if $cleaned -}}
        {{- $clean = set $clean $key $cleaned -}}
      {{- end -}}
    {{- else if kindIs "slice" $value -}}
      {{- $arr := list -}}
      {{- range $value -}}
        {{- if kindIs "map" . -}}
          {{- $ec := include "deepClean" . | fromYaml -}}
          {{- if $ec -}}
            {{- $arr = append $arr $ec -}}
          {{- end -}}
        {{- else if kindIs "string" . -}}
          {{- if ne (trim .) "" -}}
            {{- $arr = append $arr . -}}
          {{- end -}}
        {{- else -}}
          {{- $arr = append $arr . -}}
        {{- end -}}
      {{- end -}}
      {{- if $arr -}}
        {{- $clean = set $clean $key $arr -}}
      {{- end -}}
    {{- else if kindIs "string" $value -}}
      {{- if ne (trim $value) "" -}}
        {{- $clean = set $clean $key $value -}}
      {{- end -}}
    {{- else -}}
      {{- $clean = set $clean $key $value -}}
    {{- end -}}
  {{- end -}}
  {{- if $clean -}}
    {{ $clean | toYaml -}}
  {{- else -}}
    {}
  {{- end -}}
{{- else -}}
  {}
{{- end -}}
{{- end -}}

{{/*
Extract domain from OCI registry endpoint
Strips oci://, https://, http:// prefixes and removes port numbers
Usage: {{ include "ociRegistryDomain" .Values.hue.ociRegistry.endpoint }}
*/}}
{{- define "ociRegistryDomain" -}}
{{- $endpoint := . | replace "oci://" "" | replace "https://" "" | replace "http://" "" }}
{{- regexReplaceAll ":.*" $endpoint "" }}
{{- end -}}

{{/*
Get the global domain from configuration
Usage: {{ include "globalDomain" . }}
*/}}
{{- define "globalDomain" -}}
{{- if and .Values.global .Values.global.dns .Values.global.dns.domain -}}
{{- .Values.global.dns.domain -}}
{{- else -}}
{{- "replace.with.your.domain" -}}
{{- end -}}
{{- end -}}
