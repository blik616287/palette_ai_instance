# mural-crds Helm chart

## TL;DR

```bash
helm install mural-crds oci://public.ecr.aws/mural/mural-crds
```

## Prerequisites

- Kubernetes >= v1.32

## Overview

A Helm chart for managing the lifecycle of all Mural CRDs.
